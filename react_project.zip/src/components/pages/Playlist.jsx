import React from 'react'
import Header from '../include/Header'

const Playlist = () => {
  return <Header />
}

export default Playlist
