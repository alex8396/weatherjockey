import React from 'react'
import Header from '../include/Header'

const Genre = () => {
  return <Header />
}

export default Genre
