import React from 'react'
import Header from '../include/Header'

const Favorite = () => {
  return <Header />
}

export default Favorite
