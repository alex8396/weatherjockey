import React from 'react'
import Header from '../include/Header'

const Download = () => {
  return <Header />
}

export default Download
